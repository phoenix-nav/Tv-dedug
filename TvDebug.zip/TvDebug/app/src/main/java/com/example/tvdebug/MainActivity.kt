package com.example.tvdebug

import android.app.ActivityManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.app.Activity
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val tag = "TvDebug"
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding(64, 48, 64, 48)
        }
        root.addView(TextView(this).apply {
            text = "TV Debug"
            textSize = 32f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "D-pad: OK = add log line · Up/Down = scroll"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.START
        })
        logView = TextView(this).apply {
            textSize = 18f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#B2FF59"))
        }
        scroll = ScrollView(this).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            addView(logView)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        scroll.requestFocus()

        log("App started")
        deviceInfo().forEach { log(it) }
    }

    private fun deviceInfo(): List<String> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(dm)
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return listOf(
            "Model: ${Build.MANUFACTURER} ${Build.MODEL}",
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "ABI: ${Build.SUPPORTED_ABIS.joinToString()}",
            "Screen: ${dm.widthPixels}x${dm.heightPixels} @ ${dm.densityDpi}dpi",
            "RAM: ${mi.availMem / 1048576} MB free / ${mi.totalMem / 1048576} MB",
            "IP: ${localIps()}",
            "Debuggable: ${(applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0}"
        )
    }

    private fun localIps(): String = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .filter { !it.isLoopbackAddress && it.hostAddress?.contains(':') == false }
            .joinToString { it.hostAddress ?: "" }
    } catch (e: Exception) { "unknown" }

    private fun log(msg: String) {
        Log.d(tag, msg)
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logView.append("[$t] $msg\n")
        scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode != KeyEvent.KEYCODE_DPAD_UP && keyCode != KeyEvent.KEYCODE_DPAD_DOWN) {
            log("Key: ${KeyEvent.keyCodeToString(keyCode)}")
        }
        return super.onKeyDown(keyCode, event)
    }
}
